# __init__.py

# Version of the Regx-Dev package
__version__ = "1.0.0"